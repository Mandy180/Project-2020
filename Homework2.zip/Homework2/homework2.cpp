#include "homework2.h"


//STACK
//The public member functions for the stack. It will manage the discarded questions and the correctly-answered questions

//Below is the destructor for the struct node
//and struct CS_Trivia
node::~node()
{
    delete [] trivia_questions;
    trivia_questions = NULL;
}
CS_Trivia::~CS_Trivia()
{
    delete [] question;
    question = NULL;
}
//This constructor will set everything to NULL, we will start with an empty list
stack::stack()
{
    head = NULL;
    top_index = 0;
}
//For the destructor, it will call the delete-all functions to delete all of
//the new allocations
stack::~stack()
{
    if(head)
    {
        int count = delete_all(head);
    }
}
int stack::delete_all( node * &head)
{
    if(!head)
        return 0;
    node * temp = head -> next;
    delete head;
    head = temp;
    return delete_all(head) +1;
}
// The push function will add a new question to the very top of the list
// For example, the 2nd question will be on top of list when we go to display
int stack::push(char * user_input)
{

    if(!head)
    {
        head = new node;
        head -> trivia_questions = new CS_Trivia[5];
        head -> trivia_questions[top_index].question = new char[strlen(user_input) +1];
        strcpy(head -> trivia_questions[top_index].question, user_input);
        head -> next = NULL;
        ++top_index;
        return 1;
    }
    if(top_index == MAX)
    {
        top_index = 0;
        node * temp = head;
        head = new node;
        head -> trivia_questions = new CS_Trivia[5];
        head -> trivia_questions[top_index].question = new char[strlen(user_input) +1];
        strcpy(head ->trivia_questions[top_index].question, user_input);
        head -> next = temp;
        ++top_index;
        return 1;
    }

    head -> trivia_questions[top_index].question = new char[strlen(user_input) +1];
    strcpy(head -> trivia_questions[top_index].question, user_input);
    ++top_index;

    return 1;

}
//The display function will display all of the questions the user
//has added
int stack::display()
{
    if(!head)
        return 0;
    int i = top_index -1;
    node * temp = head;
    while(temp)
    {
        for(  ;i >= 0; --i)
        {
            cout << temp -> trivia_questions[i].question << endl;
        }
        temp = temp -> next;
        i = MAX - 1;
    }
    return 1;
}
//The pop function will delete the very top question of the list
//For example, it will delete the most recently added question
int stack::pop()
{
    if(head == NULL)
        return 0;
    if(top_index == 0)
    {
        node * temp = head -> next;
        delete head -> trivia_questions;
        head -> trivia_questions = NULL;
        delete head;
        head = temp;
        top_index = MAX -1;
        return 1;
    }
    else
        --top_index;
    return 1;

}

//QUEUE
//The public member functions for the queue, it will manage the trivia questions 

//The constructor to set the node to NULL
queue::queue()
{
    rear = NULL;
}
//The destructor will call the delete-all function to  delete and 
//set everything back to NULL
queue::~queue()
{
    delete_all();
}
//This function will add to the very top of the list
int queue::enqueue( char * question_input)
{
    if(!rear)
    {
        rear = new q_node;
        rear -> question = new char [strlen(question_input) +1];
        strcpy( rear -> question, question_input);
        rear -> next = rear;
        return 1;
    }
    q_node * temp = rear -> next;
    rear -> next = new q_node;
    rear = rear -> next;
    rear -> next = temp;
    rear -> question = new char [strlen(question_input)+1];
    strcpy( rear -> question, question_input);

    return 1;
}
//This function will remove from the very bottom of the list
int queue::dequeue()
{
    if(!rear)
    {
        return 0;
    }
    if(rear -> next == rear)
    {
        //   delete [] rear -> question;
        delete rear;
        rear = NULL;
        return 1;
    }
    q_node * temp = rear -> next -> next;
    // delete [] rear -> next -> question;
    delete rear -> next;
    rear -> next = temp;
    return 1;
}
//This function will display all the questions from trivia
int queue::display_all()
{
    if(!rear)
        return 0;
    return display_all(rear->next);
}
int queue::display_all(q_node * rear)
{
    if(rear == this -> rear)
    {
        cout << rear -> question << endl;
        return 0;
    }
    cout << rear -> question << endl;
    display_all( rear -> next);
    return 0;
}
//This function will allow the user a draw from 
//the trivia questions pile
int queue::display_front()
{
    if(!rear)
        return 0;
    return display_front(rear -> next);
}
int queue::display_front( q_node * rear)
{
    if(rear == this -> rear)
    {
        cout << rear -> question << endl;
        return 0;
    }
    cout << rear -> question << endl;
    return 0;
}
//The following delete function will be called by the 
//destructor
int queue::delete_all()
{
    int count = 0;
    if(!rear)
        return 0;
    delete_all(rear -> next, count);
    //delete [] rear -> question;
    delete rear;
    rear = NULL;
    return 0;
}
int queue::delete_all( q_node * & rear, int & count)
{   
    if(rear == this -> rear)
        return 0;
    ++count;
    q_node * temp = rear -> next;
    // delete [] rear -> question;
    delete rear;
    rear = NULL;
    rear = temp;
    return delete_all(rear -> next, count);
}
//This is the destructor for the questions
q_node::~q_node()
{
    delete[] question;
    question = NULL;
}





