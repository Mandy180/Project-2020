#include <iostream>
#include <cctype>
#include <cstring>
using namespace std;

//Mandy Tran
//For program number 2, we will be working with stack and queue. 
//The stack will be implemented using a LLL or arrays and queue will 
//be using a circular linked list. For the stack, each node will be 
//pointing to an array with a size limit of 5 ( 5 questions). We will always be 
//adding at the very front and increment the index by one after a new add. 
//If we want to remove from a stack, we will remove front till the end. For 
//the queue, we will always be adding at the end, and removing at the front. 


const int MAX = 5;


struct CS_Trivia
{
    ~CS_Trivia();
    char * question;
};
struct node
{
    ~node();
    CS_Trivia * trivia_questions;
    node * next;
};
class stack
{
    public:
        stack();
        ~stack();
        int push( char * user_input);
        int display();
        int pop();
        int delete_all();
        int delete_all(node * &head);
    private:
        node * head;
        int top_index;
};
struct q_node
{
    ~q_node();
    char * question;
    q_node * next;
};

class queue
{
    public:
        queue();
        ~queue();
        int enqueue(char * question_input);
        int display_all(q_node * rear);
        int display_all();
        int dequeue();
        int display_front();
        int display_front( q_node * rear);
        int delete_all();
        int delete_all( q_node * & rea, int & count);
    private:
        q_node * rear;
};
