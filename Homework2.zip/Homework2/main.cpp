#include "homework2.h"
using namespace std;

int main()
{
    int user_input = 0;
    stack discarded_questions; 
    stack correct_questions;
    queue trivia_questions;


    while( user_input == 0)
    {
        cout << "Menu Options: " << '\n' << " 1. ADD A NEW DISCARDED TRIVIA QUESTION: " << '\n'
            << " 2. REMOVE A DISCARDED TRIVIA QUESTION " << '\n' << " 3. DISPLAY ALL DISCARDED QUESTIONS " <<  '\n' <<
            " 4. ADD A NEW QUESTION THAT YOU ANSWERED CORRECTLY: " << '\n' << " 5. REMOVE A QUESTION THAT YOU ANSWERED CORRECTLY" << 
            '\n' << " 6. DISPLAY ALL OF THE QUESTIONS YOU HAVE ANSWERED CORRECTLY" << '\n' << " 7. ADD A NEW TRIVIA QUESTION: " << '\n' <<
            " 8. REMOVE A TRIVIA QUESTION " << '\n' << " 9. PLAY THE GAME: DISPLAY A TRIVIA QUESTION " << '\n' 
            << " 10. DISPLAY ALL TRIVIA QUESTIONS " << '\n' << endl;
        cin >> user_input;
        cin.ignore(100, '\n');

        //Manages the stack of discarded questions
        if( user_input == 1)
        {
            char question_input[100];
            cout << "Please enter the discarded question you would like to add:  " << endl;
            cin.get(question_input,100, '\n');
            cin.ignore( 100, '\n');
            discarded_questions.push(question_input);
        }
        if( user_input == 2)
        {
            int return_value = discarded_questions.pop();
            if(return_value == 1)
                cout <<" We have removed the top question from the list" << endl;
            else
                cout <<" ERROR!PLEASE TRY AGAIN! " << endl;
        }
        if(user_input == 3)
        {
            discarded_questions.display();
        }

        //Manages the stack of correctly-answered questions
        if(user_input == 4)
        {
            char question_input[100];
            cout << "Please enter the correctly-answered question you would like to add: " << endl;
            cin.get( question_input, 100, '\n');
            cin.ignore( 100, '\n');
            correct_questions.push(question_input);
        }
        if(user_input == 5)
        {
            int return_value = correct_questions.pop();
            if( return_value == 1)
                cout << "We have removed the top question from the list: " << endl;
            else
                cout << "ERROR! PLEASE TRY AGAIN!" << endl;
        }
        if( user_input == 6)
        {
            correct_questions.display();
        }

        //Manages the queue of trivia questions the user will draw from
        if( user_input == 7)
        {
            char question_input[100];
            cout << "Please enter a question you would like to add: " << endl;
            cin.get( question_input, 100, '\n');
            cin.ignore( 100, '\n');
            trivia_questions.enqueue(question_input);
        }
        if( user_input == 8)
        {
            int return_value = trivia_questions.dequeue();
            if( return_value == 1)
                cout << "We have removed the top question from the list " << endl;
            else
                cout << "ERROR! PLEASE TRY AGAIN! " << endl;
        }
        if( user_input == 9)
        {   
            trivia_questions.display_front();
        }
        if( user_input == 10)
        {
            trivia_questions.display_all();
        }


        cout << "Please enter 0 if you would like to go back to our menu if not enter 100" << endl;
        cin >> user_input;
        cin.ignore();
    }

    return 0;
}

